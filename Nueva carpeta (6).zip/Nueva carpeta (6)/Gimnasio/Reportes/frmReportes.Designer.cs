﻿namespace Gimnasio.Reportes
{
    partial class frmReportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.spInventario = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvListaInventario = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.spMembresias = new System.Windows.Forms.SplitContainer();
            this.lblTotalMembresia = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dtpFecha2Membresia = new System.Windows.Forms.DateTimePicker();
            this.dtpFecha1Membresia = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvListaMembresias = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.spSocios = new System.Windows.Forms.SplitContainer();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvListaSocios = new System.Windows.Forms.DataGridView();
            this.spRegistro = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvListaRegistro = new System.Windows.Forms.DataGridView();
            this.spVentaProductos = new System.Windows.Forms.SplitContainer();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvListaVentaProductos = new System.Windows.Forms.DataGridView();
            this.spVisitas = new System.Windows.Forms.SplitContainer();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvListaVisitas = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.dtpFecha1Registro = new System.Windows.Forms.DateTimePicker();
            this.button3 = new System.Windows.Forms.Button();
            this.dtpFecha2VtaProductos = new System.Windows.Forms.DateTimePicker();
            this.dtpFecha1VtaProductos = new System.Windows.Forms.DateTimePicker();
            this.button4 = new System.Windows.Forms.Button();
            this.dtpFecha1Visitas = new System.Windows.Forms.DateTimePicker();
            this.lblTotalVisitas = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblTotalVentaProductos = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spInventario)).BeginInit();
            this.spInventario.Panel1.SuspendLayout();
            this.spInventario.Panel2.SuspendLayout();
            this.spInventario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaInventario)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spMembresias)).BeginInit();
            this.spMembresias.Panel1.SuspendLayout();
            this.spMembresias.Panel2.SuspendLayout();
            this.spMembresias.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaMembresias)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spSocios)).BeginInit();
            this.spSocios.Panel1.SuspendLayout();
            this.spSocios.Panel2.SuspendLayout();
            this.spSocios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaSocios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spRegistro)).BeginInit();
            this.spRegistro.Panel1.SuspendLayout();
            this.spRegistro.Panel2.SuspendLayout();
            this.spRegistro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spVentaProductos)).BeginInit();
            this.spVentaProductos.Panel1.SuspendLayout();
            this.spVentaProductos.Panel2.SuspendLayout();
            this.spVentaProductos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVentaProductos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spVisitas)).BeginInit();
            this.spVisitas.Panel1.SuspendLayout();
            this.spVisitas.Panel2.SuspendLayout();
            this.spVisitas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVisitas)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1008, 682);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.spInventario);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1000, 649);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Inventario";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // spInventario
            // 
            this.spInventario.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spInventario.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spInventario.IsSplitterFixed = true;
            this.spInventario.Location = new System.Drawing.Point(3, 3);
            this.spInventario.Margin = new System.Windows.Forms.Padding(4);
            this.spInventario.Name = "spInventario";
            this.spInventario.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spInventario.Panel1
            // 
            this.spInventario.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spInventario.Panel1.Controls.Add(this.label1);
            this.spInventario.Panel1MinSize = 100;
            // 
            // spInventario.Panel2
            // 
            this.spInventario.Panel2.Controls.Add(this.dgvListaInventario);
            this.spInventario.Panel2MinSize = 100;
            this.spInventario.Size = new System.Drawing.Size(994, 643);
            this.spInventario.SplitterDistance = 100;
            this.spInventario.SplitterWidth = 3;
            this.spInventario.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reporte que muestra el inventario existente";
            // 
            // dgvListaInventario
            // 
            this.dgvListaInventario.AllowUserToAddRows = false;
            this.dgvListaInventario.AllowUserToDeleteRows = false;
            this.dgvListaInventario.AllowUserToResizeRows = false;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaInventario.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvListaInventario.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaInventario.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaInventario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaInventario.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaInventario.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaInventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaInventario.DefaultCellStyle = dataGridViewCellStyle30;
            this.dgvListaInventario.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaInventario.Location = new System.Drawing.Point(0, 0);
            this.dgvListaInventario.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaInventario.MultiSelect = false;
            this.dgvListaInventario.Name = "dgvListaInventario";
            this.dgvListaInventario.ReadOnly = true;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaInventario.RowHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvListaInventario.RowHeadersVisible = false;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaInventario.RowsDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvListaInventario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaInventario.Size = new System.Drawing.Size(994, 540);
            this.dgvListaInventario.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.spMembresias);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1000, 649);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Membresias";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // spMembresias
            // 
            this.spMembresias.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spMembresias.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spMembresias.IsSplitterFixed = true;
            this.spMembresias.Location = new System.Drawing.Point(3, 3);
            this.spMembresias.Margin = new System.Windows.Forms.Padding(4);
            this.spMembresias.Name = "spMembresias";
            this.spMembresias.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spMembresias.Panel1
            // 
            this.spMembresias.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spMembresias.Panel1.Controls.Add(this.lblTotalMembresia);
            this.spMembresias.Panel1.Controls.Add(this.label3);
            this.spMembresias.Panel1.Controls.Add(this.button1);
            this.spMembresias.Panel1.Controls.Add(this.dtpFecha2Membresia);
            this.spMembresias.Panel1.Controls.Add(this.dtpFecha1Membresia);
            this.spMembresias.Panel1.Controls.Add(this.label2);
            this.spMembresias.Panel1MinSize = 100;
            // 
            // spMembresias.Panel2
            // 
            this.spMembresias.Panel2.Controls.Add(this.dgvListaMembresias);
            this.spMembresias.Panel2MinSize = 100;
            this.spMembresias.Size = new System.Drawing.Size(994, 643);
            this.spMembresias.SplitterDistance = 100;
            this.spMembresias.SplitterWidth = 3;
            this.spMembresias.TabIndex = 2;
            // 
            // lblTotalMembresia
            // 
            this.lblTotalMembresia.AutoSize = true;
            this.lblTotalMembresia.Location = new System.Drawing.Point(828, 69);
            this.lblTotalMembresia.Name = "lblTotalMembresia";
            this.lblTotalMembresia.Size = new System.Drawing.Size(44, 20);
            this.lblTotalMembresia.TabIndex = 6;
            this.lblTotalMembresia.Text = "$ 0.0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(761, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(333, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 26);
            this.button1.TabIndex = 4;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtpFecha2Membresia
            // 
            this.dtpFecha2Membresia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha2Membresia.Location = new System.Drawing.Point(179, 21);
            this.dtpFecha2Membresia.Name = "dtpFecha2Membresia";
            this.dtpFecha2Membresia.Size = new System.Drawing.Size(125, 26);
            this.dtpFecha2Membresia.TabIndex = 3;
            this.dtpFecha2Membresia.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // dtpFecha1Membresia
            // 
            this.dtpFecha1Membresia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha1Membresia.Location = new System.Drawing.Point(29, 21);
            this.dtpFecha1Membresia.Name = "dtpFecha1Membresia";
            this.dtpFecha1Membresia.Size = new System.Drawing.Size(131, 26);
            this.dtpFecha1Membresia.TabIndex = 2;
            this.dtpFecha1Membresia.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(496, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Reporte que muestra las membresias vendidas en un rango de fecha";
            // 
            // dgvListaMembresias
            // 
            this.dgvListaMembresias.AllowUserToAddRows = false;
            this.dgvListaMembresias.AllowUserToDeleteRows = false;
            this.dgvListaMembresias.AllowUserToResizeRows = false;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaMembresias.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvListaMembresias.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaMembresias.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaMembresias.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaMembresias.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaMembresias.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaMembresias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaMembresias.DefaultCellStyle = dataGridViewCellStyle34;
            this.dgvListaMembresias.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaMembresias.Location = new System.Drawing.Point(0, 0);
            this.dgvListaMembresias.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaMembresias.MultiSelect = false;
            this.dgvListaMembresias.Name = "dgvListaMembresias";
            this.dgvListaMembresias.ReadOnly = true;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaMembresias.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvListaMembresias.RowHeadersVisible = false;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaMembresias.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvListaMembresias.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaMembresias.Size = new System.Drawing.Size(994, 540);
            this.dgvListaMembresias.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.spSocios);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1000, 649);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Socios";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.spRegistro);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1000, 649);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Registro";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.spVentaProductos);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1000, 649);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Venta de Productos";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.spVisitas);
            this.tabPage6.Location = new System.Drawing.Point(4, 29);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1000, 649);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Visitas";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // spSocios
            // 
            this.spSocios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spSocios.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spSocios.IsSplitterFixed = true;
            this.spSocios.Location = new System.Drawing.Point(0, 0);
            this.spSocios.Margin = new System.Windows.Forms.Padding(4);
            this.spSocios.Name = "spSocios";
            this.spSocios.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spSocios.Panel1
            // 
            this.spSocios.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spSocios.Panel1.Controls.Add(this.label4);
            this.spSocios.Panel1MinSize = 100;
            // 
            // spSocios.Panel2
            // 
            this.spSocios.Panel2.Controls.Add(this.dgvListaSocios);
            this.spSocios.Panel2MinSize = 100;
            this.spSocios.Size = new System.Drawing.Size(1000, 649);
            this.spSocios.SplitterDistance = 100;
            this.spSocios.SplitterWidth = 3;
            this.spSocios.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(518, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Reporte que muestra el listado de socios con la fecha de su vencimiento";
            // 
            // dgvListaSocios
            // 
            this.dgvListaSocios.AllowUserToAddRows = false;
            this.dgvListaSocios.AllowUserToDeleteRows = false;
            this.dgvListaSocios.AllowUserToResizeRows = false;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaSocios.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvListaSocios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaSocios.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaSocios.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaSocios.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaSocios.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaSocios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaSocios.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvListaSocios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaSocios.Location = new System.Drawing.Point(0, 0);
            this.dgvListaSocios.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaSocios.MultiSelect = false;
            this.dgvListaSocios.Name = "dgvListaSocios";
            this.dgvListaSocios.ReadOnly = true;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaSocios.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvListaSocios.RowHeadersVisible = false;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaSocios.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvListaSocios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaSocios.Size = new System.Drawing.Size(1000, 546);
            this.dgvListaSocios.TabIndex = 0;
            // 
            // spRegistro
            // 
            this.spRegistro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spRegistro.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spRegistro.IsSplitterFixed = true;
            this.spRegistro.Location = new System.Drawing.Point(0, 0);
            this.spRegistro.Margin = new System.Windows.Forms.Padding(4);
            this.spRegistro.Name = "spRegistro";
            this.spRegistro.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spRegistro.Panel1
            // 
            this.spRegistro.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spRegistro.Panel1.Controls.Add(this.button2);
            this.spRegistro.Panel1.Controls.Add(this.dtpFecha1Registro);
            this.spRegistro.Panel1.Controls.Add(this.label5);
            this.spRegistro.Panel1MinSize = 100;
            // 
            // spRegistro.Panel2
            // 
            this.spRegistro.Panel2.Controls.Add(this.dgvListaRegistro);
            this.spRegistro.Panel2MinSize = 100;
            this.spRegistro.Size = new System.Drawing.Size(1000, 649);
            this.spRegistro.SplitterDistance = 100;
            this.spRegistro.SplitterWidth = 3;
            this.spRegistro.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(304, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Reporte que muestra el registro por fecha";
            // 
            // dgvListaRegistro
            // 
            this.dgvListaRegistro.AllowUserToAddRows = false;
            this.dgvListaRegistro.AllowUserToDeleteRows = false;
            this.dgvListaRegistro.AllowUserToResizeRows = false;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaRegistro.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.dgvListaRegistro.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaRegistro.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaRegistro.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaRegistro.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaRegistro.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaRegistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaRegistro.DefaultCellStyle = dataGridViewCellStyle42;
            this.dgvListaRegistro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaRegistro.Location = new System.Drawing.Point(0, 0);
            this.dgvListaRegistro.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaRegistro.MultiSelect = false;
            this.dgvListaRegistro.Name = "dgvListaRegistro";
            this.dgvListaRegistro.ReadOnly = true;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaRegistro.RowHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.dgvListaRegistro.RowHeadersVisible = false;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaRegistro.RowsDefaultCellStyle = dataGridViewCellStyle44;
            this.dgvListaRegistro.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaRegistro.Size = new System.Drawing.Size(1000, 546);
            this.dgvListaRegistro.TabIndex = 0;
            // 
            // spVentaProductos
            // 
            this.spVentaProductos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spVentaProductos.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spVentaProductos.IsSplitterFixed = true;
            this.spVentaProductos.Location = new System.Drawing.Point(0, 0);
            this.spVentaProductos.Margin = new System.Windows.Forms.Padding(4);
            this.spVentaProductos.Name = "spVentaProductos";
            this.spVentaProductos.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spVentaProductos.Panel1
            // 
            this.spVentaProductos.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spVentaProductos.Panel1.Controls.Add(this.lblTotalVentaProductos);
            this.spVentaProductos.Panel1.Controls.Add(this.label10);
            this.spVentaProductos.Panel1.Controls.Add(this.button3);
            this.spVentaProductos.Panel1.Controls.Add(this.dtpFecha2VtaProductos);
            this.spVentaProductos.Panel1.Controls.Add(this.dtpFecha1VtaProductos);
            this.spVentaProductos.Panel1.Controls.Add(this.label6);
            this.spVentaProductos.Panel1MinSize = 100;
            // 
            // spVentaProductos.Panel2
            // 
            this.spVentaProductos.Panel2.Controls.Add(this.dgvListaVentaProductos);
            this.spVentaProductos.Panel2MinSize = 100;
            this.spVentaProductos.Size = new System.Drawing.Size(1000, 649);
            this.spVentaProductos.SplitterDistance = 100;
            this.spVentaProductos.SplitterWidth = 3;
            this.spVentaProductos.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(316, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Reporte que muestra el inventario existente";
            // 
            // dgvListaVentaProductos
            // 
            this.dgvListaVentaProductos.AllowUserToAddRows = false;
            this.dgvListaVentaProductos.AllowUserToDeleteRows = false;
            this.dgvListaVentaProductos.AllowUserToResizeRows = false;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVentaProductos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvListaVentaProductos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaVentaProductos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaVentaProductos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaVentaProductos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaVentaProductos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaVentaProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaVentaProductos.DefaultCellStyle = dataGridViewCellStyle26;
            this.dgvListaVentaProductos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaVentaProductos.Location = new System.Drawing.Point(0, 0);
            this.dgvListaVentaProductos.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaVentaProductos.MultiSelect = false;
            this.dgvListaVentaProductos.Name = "dgvListaVentaProductos";
            this.dgvListaVentaProductos.ReadOnly = true;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaVentaProductos.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvListaVentaProductos.RowHeadersVisible = false;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVentaProductos.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvListaVentaProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaVentaProductos.Size = new System.Drawing.Size(1000, 546);
            this.dgvListaVentaProductos.TabIndex = 0;
            // 
            // spVisitas
            // 
            this.spVisitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spVisitas.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spVisitas.IsSplitterFixed = true;
            this.spVisitas.Location = new System.Drawing.Point(0, 0);
            this.spVisitas.Margin = new System.Windows.Forms.Padding(4);
            this.spVisitas.Name = "spVisitas";
            this.spVisitas.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spVisitas.Panel1
            // 
            this.spVisitas.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.spVisitas.Panel1.Controls.Add(this.lblTotalVisitas);
            this.spVisitas.Panel1.Controls.Add(this.label9);
            this.spVisitas.Panel1.Controls.Add(this.button4);
            this.spVisitas.Panel1.Controls.Add(this.dtpFecha1Visitas);
            this.spVisitas.Panel1.Controls.Add(this.label7);
            this.spVisitas.Panel1MinSize = 100;
            // 
            // spVisitas.Panel2
            // 
            this.spVisitas.Panel2.Controls.Add(this.dgvListaVisitas);
            this.spVisitas.Panel2MinSize = 100;
            this.spVisitas.Size = new System.Drawing.Size(1000, 649);
            this.spVisitas.SplitterDistance = 100;
            this.spVisitas.SplitterWidth = 3;
            this.spVisitas.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(491, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Reporte que muestra los registros de visitas realizadas en una fecha";
            // 
            // dgvListaVisitas
            // 
            this.dgvListaVisitas.AllowUserToAddRows = false;
            this.dgvListaVisitas.AllowUserToDeleteRows = false;
            this.dgvListaVisitas.AllowUserToResizeRows = false;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVisitas.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle45;
            this.dgvListaVisitas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvListaVisitas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvListaVisitas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.dgvListaVisitas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvListaVisitas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvListaVisitas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaVisitas.DefaultCellStyle = dataGridViewCellStyle46;
            this.dgvListaVisitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListaVisitas.Location = new System.Drawing.Point(0, 0);
            this.dgvListaVisitas.Margin = new System.Windows.Forms.Padding(4);
            this.dgvListaVisitas.MultiSelect = false;
            this.dgvListaVisitas.Name = "dgvListaVisitas";
            this.dgvListaVisitas.ReadOnly = true;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaVisitas.RowHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.dgvListaVisitas.RowHeadersVisible = false;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvListaVisitas.RowsDefaultCellStyle = dataGridViewCellStyle48;
            this.dgvListaVisitas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaVisitas.Size = new System.Drawing.Size(1000, 546);
            this.dgvListaVisitas.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(343, 24);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 26);
            this.button2.TabIndex = 7;
            this.button2.Text = "Buscar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dtpFecha1Registro
            // 
            this.dtpFecha1Registro.Location = new System.Drawing.Point(21, 24);
            this.dtpFecha1Registro.Name = "dtpFecha1Registro";
            this.dtpFecha1Registro.Size = new System.Drawing.Size(298, 26);
            this.dtpFecha1Registro.TabIndex = 5;
            this.dtpFecha1Registro.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(325, 26);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(107, 26);
            this.button3.TabIndex = 10;
            this.button3.Text = "Buscar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dtpFecha2VtaProductos
            // 
            this.dtpFecha2VtaProductos.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha2VtaProductos.Location = new System.Drawing.Point(171, 26);
            this.dtpFecha2VtaProductos.Name = "dtpFecha2VtaProductos";
            this.dtpFecha2VtaProductos.Size = new System.Drawing.Size(125, 26);
            this.dtpFecha2VtaProductos.TabIndex = 9;
            this.dtpFecha2VtaProductos.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // dtpFecha1VtaProductos
            // 
            this.dtpFecha1VtaProductos.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha1VtaProductos.Location = new System.Drawing.Point(21, 26);
            this.dtpFecha1VtaProductos.Name = "dtpFecha1VtaProductos";
            this.dtpFecha1VtaProductos.Size = new System.Drawing.Size(131, 26);
            this.dtpFecha1VtaProductos.TabIndex = 8;
            this.dtpFecha1VtaProductos.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(320, 27);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(107, 26);
            this.button4.TabIndex = 13;
            this.button4.Text = "Buscar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dtpFecha1Visitas
            // 
            this.dtpFecha1Visitas.Location = new System.Drawing.Point(16, 27);
            this.dtpFecha1Visitas.Name = "dtpFecha1Visitas";
            this.dtpFecha1Visitas.Size = new System.Drawing.Size(289, 26);
            this.dtpFecha1Visitas.TabIndex = 11;
            this.dtpFecha1Visitas.Value = new System.DateTime(2012, 11, 30, 0, 0, 0, 0);
            // 
            // lblTotalVisitas
            // 
            this.lblTotalVisitas.AutoSize = true;
            this.lblTotalVisitas.Location = new System.Drawing.Point(871, 69);
            this.lblTotalVisitas.Name = "lblTotalVisitas";
            this.lblTotalVisitas.Size = new System.Drawing.Size(44, 20);
            this.lblTotalVisitas.TabIndex = 15;
            this.lblTotalVisitas.Text = "$ 0.0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(804, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Total";
            // 
            // lblTotalVentaProductos
            // 
            this.lblTotalVentaProductos.AutoSize = true;
            this.lblTotalVentaProductos.Location = new System.Drawing.Point(794, 69);
            this.lblTotalVentaProductos.Name = "lblTotalVentaProductos";
            this.lblTotalVentaProductos.Size = new System.Drawing.Size(44, 20);
            this.lblTotalVentaProductos.TabIndex = 12;
            this.lblTotalVentaProductos.Text = "$ 0.0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(617, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Total de la ganancia";
            // 
            // frmReportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.ClientSize = new System.Drawing.Size(1008, 682);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1024, 720);
            this.Name = "frmReportes";
            this.Text = "Reportes";
            this.Load += new System.EventHandler(this.frmReportes_Load);
            this.Enter += new System.EventHandler(this.frmReportes_Enter);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.spInventario.Panel1.ResumeLayout(false);
            this.spInventario.Panel1.PerformLayout();
            this.spInventario.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spInventario)).EndInit();
            this.spInventario.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaInventario)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.spMembresias.Panel1.ResumeLayout(false);
            this.spMembresias.Panel1.PerformLayout();
            this.spMembresias.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spMembresias)).EndInit();
            this.spMembresias.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaMembresias)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.spSocios.Panel1.ResumeLayout(false);
            this.spSocios.Panel1.PerformLayout();
            this.spSocios.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spSocios)).EndInit();
            this.spSocios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaSocios)).EndInit();
            this.spRegistro.Panel1.ResumeLayout(false);
            this.spRegistro.Panel1.PerformLayout();
            this.spRegistro.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spRegistro)).EndInit();
            this.spRegistro.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaRegistro)).EndInit();
            this.spVentaProductos.Panel1.ResumeLayout(false);
            this.spVentaProductos.Panel1.PerformLayout();
            this.spVentaProductos.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spVentaProductos)).EndInit();
            this.spVentaProductos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVentaProductos)).EndInit();
            this.spVisitas.Panel1.ResumeLayout(false);
            this.spVisitas.Panel1.PerformLayout();
            this.spVisitas.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spVisitas)).EndInit();
            this.spVisitas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaVisitas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        public System.Windows.Forms.SplitContainer spInventario;
        public System.Windows.Forms.DataGridView dgvListaInventario;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.SplitContainer spMembresias;
        public System.Windows.Forms.DataGridView dgvListaMembresias;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dtpFecha2Membresia;
        private System.Windows.Forms.DateTimePicker dtpFecha1Membresia;
        private System.Windows.Forms.Label lblTotalMembresia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage6;
        public System.Windows.Forms.SplitContainer spSocios;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.DataGridView dgvListaSocios;
        public System.Windows.Forms.SplitContainer spRegistro;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.DataGridView dgvListaRegistro;
        public System.Windows.Forms.SplitContainer spVentaProductos;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.DataGridView dgvListaVentaProductos;
        public System.Windows.Forms.SplitContainer spVisitas;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.DataGridView dgvListaVisitas;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker dtpFecha1Registro;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker dtpFecha2VtaProductos;
        private System.Windows.Forms.DateTimePicker dtpFecha1VtaProductos;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DateTimePicker dtpFecha1Visitas;
        private System.Windows.Forms.Label lblTotalVisitas;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblTotalVentaProductos;
        private System.Windows.Forms.Label label10;
    }
}