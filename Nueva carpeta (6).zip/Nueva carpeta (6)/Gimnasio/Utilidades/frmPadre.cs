﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Gimnasio.Utilidades
{
    public partial class frmPadre : Form
    {
        public frmPadre()
        {
            InitializeComponent();
        }

        private void frmPadre_Load(object sender, EventArgs e)
        {

        }

        private void spContenedor_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void cmdModificar_Click(object sender, EventArgs e)
        {

        }
    }
}
