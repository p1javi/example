﻿namespace Gimnasio {
    
    
    public partial class dsGimnasio {
    }
}
namespace Gimnasio {
    
    
    public partial class dsGimnasio {
    }
}
